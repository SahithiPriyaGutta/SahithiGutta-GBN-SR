CCN Programming Project 1 - Implementation of GBN and SR Protocols

Project Members: 

* Ravi Teja Kolla 
* Sahithi Priya Gutta

********************************************************************************

Compiling:
=====================================================
Sender - 

* Open the terminal and go to the path where .java files related to sender are saved.
Ex: In our case it is "C:\Users\sahit\eclipse-workspace\CCNProgrammingProject\src"

* Compile .java file using the command "javac filename.java".
Ex: In our case it is "javac Sender.java"

Receiver - 

* Open the terminal and go to the path where .java files related to receiver are saved.
Ex: In our case it is "C:\Users\sahit\eclipse-workspace\CCNProgrammingProject\src"

* Compile .java file using the command "javac filename.java".
Ex: In our case it is "javac Reciever.java"

Running:
======================================================
Receiver - 

* Run the receiver by providing a valid input file path and port number.
In our case it is "java Reciever <inputfile path> <portNum>"

Now the Receiver becomes active.

Sender - 

* Run the sender by providing a valid input file path, port number and number of packets.
In our case it is "java Sender <inputfile path> <portNum> <no. of packets>"

==============================================================

* Input file name in code - sender.txt

           - If we want to get the output for GBN protocol, then the inputs in the input file sender.txt should contain Protocol Name i.e; GBN, no. of bits used in sequence numbers, window size, timeout period, size of the segment in bytes.

           - If we want to get the output for SR protocol, then the inputs in the input file sender.txt should contain Protocol Name i.e; SR, no. of bits used in sequence numbers, window size, timeout period, size of the segment in bytes.

In our case the input file path is "C:\Users\sahit\eclipse-workspace\CCNProgrammingProject\src\sender.txt"

* Port Number example - 6000

* Number of packets - 1000

=======================================================

* Sender and Reciever are main programs. Packet and Ack are utility code for sender and receiver.

* SampleTextFile_10kb.txt is the file which is going to get transferred to the receiver by getting divided into chunks (which is packets in our case).

* output.txt is the place where all the packets get written.

=======================================================

Place the sample file in the main repo.

            - If you want to change the file in sender i.e; if you are using a different file, then there is a variable in Sender program  transferFile. Change that value and place the transfer file in main repo and run.
