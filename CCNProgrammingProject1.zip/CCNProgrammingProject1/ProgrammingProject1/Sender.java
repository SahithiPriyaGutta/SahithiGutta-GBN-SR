/* CCN Programming Project 1 - Implementation of GBN and SR Protocols
 ** Project Members - Ravi Teja Kolla and Sahithi Priya Gutta
*/

import java.io.*;
import java.net.*;
import java.util.*;

public class Sender {

    public static String transferFile = "SampleTextFile_10kb.txt";

    public static double LOST_PACKET = 0.1;

    public static void main(String[] args ){

        if (args.length != 3){
            System.out.println("Not enough arguments expected 3 but got " + args.length);
            return;
        }

        String parameters  = args[0];
        int recieverport,packets;

        try{
            recieverport = Integer.parseInt(args[1]);
        }
        catch (Exception e){
            System.out.println("Invalid Port Number");
            return;
        }

        try{
            packets = Integer.parseInt(args[2]);
        }
        catch (Exception e){
            System.out.println("Invalid packet count");
            return;
        }
        List<String> lines = new ArrayList<>();
        try {
            BufferedReader br = new BufferedReader(new FileReader(parameters));
            recieverport = Integer.parseInt(args[1]);

            String line;
            while ((line = br.readLine()) != null) {
                lines.add(line.trim());
            }
            br.close();
        }catch (Exception e){
            System.out.println("Invalid File");
        }
            String protocol = lines.get(0);

            int m = Integer.parseInt(lines.get(1).split(" ")[0].trim());
            int N = Integer.parseInt(lines.get(1).split(" ")[1].trim());

            int timeout = Integer.parseInt(lines.get(2));
            int size = Integer.parseInt(lines.get(3));
            try {

                DatagramSocket recieverSocket = new DatagramSocket();
                InetAddress IpAddress = InetAddress.getByName("localhost");
                File file = new File(transferFile);
                FileInputStream fis = new FileInputStream(file);
                byte[] data = new byte[(int) file.length()];
                fis.read(data);
                fis.close();

                int filesize = data.length;
                int x = (int) (Math.pow(2.0, (double) m));
                
                System.out.println("***********************************");
                System.out.println("Using Protocol " + protocol);
                System.out.println("***********************************");

                if (protocol.equals("GBN")) {

                    int lastPacket = filesize / size;
                    boolean endOfFile = false;
                    int packetNo = 0;
                    int waitingForAck = 0;
                    long Start = System.currentTimeMillis();
                    Queue<Integer> unAckedPackets = new ArrayDeque<>();

                    for (int i = 0; i < N; i++) {
                        unAckedPackets.add(i);
                    }
                    while (waitingForAck <= lastPacket) {

                        // Check if window space is free and send packets in free space
                        while (packetNo - waitingForAck < N && !endOfFile) {

                            // Start timer for the sent packet
                            Start = System.currentTimeMillis();
                            int startByte = packetNo * size;
                            int endByte = (packetNo + 1) * size;

                            if (endByte > filesize) {
                                System.out.println("End of File");
                                endOfFile = true;
                            }

                            // Split transfering file into packets of size equal to MSS Bytes
                            byte[] partData = Arrays.copyOfRange(data, startByte, endByte > filesize ? filesize : endByte);

                            // Calcuate pack seq no. from the actual seq no.
                            int sqeNo = packetNo % x;


                            // Create transfer packet from the data
                            Packet dataPacket = new Packet(sqeNo, partData, endOfFile);

                            // Generate bytes array from the packet data
                            byte[] sendData = dataPacket.generatePacket();

                            DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, IpAddress, recieverport);

                            // Induce Lost packet Error. Says Sending packet but actually the packet is lost
                            if (Math.random() > LOST_PACKET) {
                                recieverSocket.send(sendPacket);
                            } else {
                                System.out.print("Lost Packet: " + sqeNo + "; ");
                            }

                            // Message for sending packet
                            System.out.println("Sending " + sqeNo + ";");
                            packetNo++;
                        }

                        // Create packet to receive data
                        byte[] receiveData = new byte[4];
                        DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);

                        try {

                            // Calculate time left from the actual start time
                            long TIMER = timeout - (System.currentTimeMillis() - Start);

                            // Raise timeout if timer is less than zero
                            if (TIMER < 0) {
                                throw new SocketTimeoutException();
                            }

                            // Set timeout to socket for receiving ack
                            recieverSocket.setSoTimeout((int) TIMER);

                            // Receive ack
                            recieverSocket.receive(receivePacket);

                            // Decode received ack to get Seq No
                            Ack ackPacket = new Ack(receivePacket.getData());

                            // Adding a delay in response to show a clear flow of things
                            Thread.sleep(100);
                            System.out.println("");
                            System.out.println("Received ACK: " + ackPacket.getSeqNum());

                            // Check if ACK received is part of the window
                            if (unAckedPackets.contains(ackPacket.getSeqNum())) {

                                // If ACK received is of packet after what we are expecting. Then account for LOST ACK and slide window by required size
                                while (ackPacket.getSeqNum() != unAckedPackets.poll()) {
                                    Start = System.currentTimeMillis();
                                    unAckedPackets.add((waitingForAck + N) % x);
                                    waitingForAck++;
                                }
                                unAckedPackets.add((waitingForAck + N) % x);
                                waitingForAck++;
                            }
                        } catch (Exception e) {

                            // Expected packet not delivered. Re-Send that and all packets after that
                            String message = "Packet " + waitingForAck % x + ": Timer expired; Resending";

                            for (int i = waitingForAck; i < packetNo; i++) {

                                int sqeNo = i % x;

                                message += (" " + sqeNo);

                                int startByte = i * size;
                                int endByte = (i + 1) * size;

                                byte[] partData = Arrays.copyOfRange(data, startByte, endByte > filesize ? filesize : endByte);

                                Packet dataPacket = new Packet(sqeNo, partData, endByte > filesize);

                                byte[] sendData = dataPacket.generatePacket();

                                DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, IpAddress, recieverport);

                                // Induce lost packet Error
                                if (Math.random() > LOST_PACKET) {
                                    recieverSocket.send(sendPacket);
                                } else {
                                    System.out.println("Lost Packet: " + sqeNo);
                                }
                            }

                            // Restart Timer
                            Start = System.currentTimeMillis();

                            message += "; Timer started";

                            System.out.println(message);
                            System.out.println("");
                        }

                    }
                    System.out.println("closing socket");
                    recieverSocket.close();
                } else if (protocol.equals("SR")) {
                    HashMap<Integer, Long> packetTimers = new HashMap<Integer, Long>();
                    HashMap<Integer, Ack> recievedAcks = new HashMap<Integer, Ack>();
                    int lastPacket = filesize / size;
                    boolean endOfFile = false;
                    int packetNo = 0;
                    int waitingForAck = 0;
                    Queue<Integer> unAckedPackets = new ArrayDeque<>();

                    for (int i = 0; i < N; i++) {
                        unAckedPackets.add(i);
                    }

                    while (waitingForAck <= lastPacket) {

                        while (packetNo - waitingForAck < N && !endOfFile) {
                            packetTimers.put(packetNo, System.currentTimeMillis());

                            int startByte = packetNo * size;
                            int endByte = (packetNo + 1) * size;

                            if (endByte > filesize) {
                                System.out.println("End of File");
                                endOfFile = true;
                            }

                            // Split transfering file into packets of size equal to MSS Bytes
                            byte[] partData = Arrays.copyOfRange(data, startByte, endByte > filesize ? filesize : endByte);

                            // Create Packet from the data
                            Packet dataPacket = new Packet(packetNo % x, partData, endOfFile);

                            // Covert packet to Bytes array
                            byte[] sendData = dataPacket.generatePacket();

                            // Create Datagram Packet
                            DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, IpAddress, recieverport);

                            // Induce Lost Packet Error. It says packet sent but it wont send the packet
                            if (Math.random() > LOST_PACKET) {
                                recieverSocket.send(sendPacket);
                            } else {
                                System.out.println("Lost Packet: " + packetNo % x);
                            }

                            // Sending packet message
                            System.out.println("Sending " + packetNo % x + ";");

                            packetNo++;
                        }

                        byte[] receiveData = new byte[4];
                        DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);

                        try {

                            // Calculate remaining time for the expecting packet
                            long TIMER = timeout - (System.currentTimeMillis() - packetTimers.get(waitingForAck));

                            // If timer expires raise Timeout Exception
                            if (TIMER < 0) {
                                throw new SocketTimeoutException();
                            }

                            // Set Timeout to receiveing socket
                            recieverSocket.setSoTimeout((int) TIMER);

                            // Receive ACK Packet
                            recieverSocket.receive(receivePacket);

                            // Decode ACK Packet
                            Ack ackPacket = new Ack(receivePacket.getData());

                            // Mesage to show received ACK
                            System.out.println("Received ACK: " + ackPacket.getSeqNum());

                            ArrayList<Integer> WINDOW_LIST = new ArrayList<Integer>(unAckedPackets);

                            // Get actual Seq No. of received ACK
                            int actualSeqNo = waitingForAck + WINDOW_LIST.indexOf(ackPacket.getSeqNum());

                            // Store received acks to know out of order acks
                            recievedAcks.put(actualSeqNo, ackPacket);

                            // Adding a delay in response to show a clear flow of things

                            // Check for received ACK's in sequence and clear the window for sending more packets
                            while (recievedAcks.containsKey(waitingForAck)) {
                                unAckedPackets.add((waitingForAck + N) % x);
                                waitingForAck++;
                                unAckedPackets.remove();
                            }

                            System.out.println("");
                        } catch (SocketTimeoutException e) {

                            // Packet ACK not received. Time out occured. Resendig the packet

                            System.out.println("Packet " + waitingForAck % x + ": Timer expired; Resending " + waitingForAck % x);

                            int startByte = waitingForAck * size;
                            int endByte = (waitingForAck + 1) * size;

                            byte[] partData = Arrays.copyOfRange(data, startByte, endByte > filesize ? filesize : endByte);

                            Packet dataPacket = new Packet(waitingForAck % x, partData, endByte > filesize);

                            byte[] sendData = dataPacket.generatePacket();

                            DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, IpAddress, recieverport);

                            // Induce Lost packet error
                            if (Math.random() > LOST_PACKET) {
                                recieverSocket.send(sendPacket);
                            } else {
                                System.out.println("Lost Packet: " + waitingForAck % x);
                            }

                            // Reset timer for resent packet
                            packetTimers.put(waitingForAck, System.currentTimeMillis());

                            System.out.println("Timer Re-started");
                        }
                    }

                    recieverSocket.close();

                }
            }
            catch (IOException e){
                System.out.println(e);
            }


    }

}
