/* CCN Programming Project 1 - Implementation of GBN and SR Protocols
 ** Project Members - Ravi Teja Kolla and Sahithi Priya Gutta
*/

import java.nio.ByteBuffer;


// Reliable data transfer ACK packet class to create an ACK packet with sequence no.
public class Ack{

    private int seqNum;

    public Ack(int seqNo) {
        this.seqNum = seqNo;
    }

    public Ack(byte[] packet) {
        ByteBuffer wrapped = ByteBuffer.wrap(packet);
        this.seqNum = wrapped.getInt();
    }

    public int getSeqNum() {
        return seqNum;
    }

    public void setSeqNum(int seqNum) {
        this.seqNum = seqNum;
    }

    public byte[] generatePacket(){

        byte[] packet = ByteBuffer.allocate(4).putInt(this.seqNum).array();

        return packet;
    }

    @Override
    public String toString() {
        return "RDT Acknowledgement Packet [seq=" + seqNum + "]";
    }

}
