/* CCN Programming Project 1 - Implementation of GBN and SR Protocols
 ** Project Members - Ravi Teja Kolla and Sahithi Priya Gutta
*/

import java.nio.ByteBuffer;
import java.util.Arrays;

public class Packet {
    private int seqNum;
    private byte[] data;
    private String checksum;
    private boolean last;
    private Double checksum_error = 0.1;

    public Packet(int seqNum,byte[] data, boolean last){
        this.seqNum = seqNum;
        this.data = data;
        this.last = last;
    }

    public Packet(byte[] data,int length){
        this.checksum = new String(Arrays.copyOfRange(data,0,16));
        this.last = Integer.valueOf(data[16]) == 1 ? true : false;

        byte[] seqNum = Arrays.copyOfRange(data,17,21);
        this.seqNum = ByteBuffer.wrap(seqNum).getInt();
        this.data = Arrays.copyOfRange(data,21,length);
    }

    public int getSeqNum() {
        return seqNum;
    }

    public void setSeqNum(int seqNum) {
        this.seqNum = seqNum;
    }

    public byte[] getData() {
        return data;
    }

    public void setData(byte[] data) {
        this.data = data;
    }


    public boolean getLast() {
        return last;
    }

    public void setLast(boolean last) {
        this.last = last;
    }

    public String onesComp(String value){
        String onescomp = "";
        for (int i=0; i< value.length();i++){
            if(value.charAt(i) == '0'){
                onescomp += '1';
            }
            else {
                onescomp += '0';
            }
        }
        return onescomp;
    }

    public String onesCompSum(String value1,String value2){
        int data1 = Integer.parseInt(value1,2);
        int data2 = Integer.parseInt(value2,2);
        int sum = data1+data2;

        String result = Integer.toString(sum,2);

        while(result.length() > 16 && result.charAt(0) == '1'){

            data1 = Integer.parseInt(result.substring(1),2);
            data2 = Integer.parseInt(result.substring(0,1),2);
            sum = data1 + data2;
            result = Integer.toString(sum,2);
        }
        return result;
    }

    public String genCheckSum(byte[] data){
        String[] binary = new String[data.length /2];

        for (int i=0; i< data.length;i += 2) {
            if (i+1 >= data.length) break;
            binary[i/2] = Integer.toString(((data[i]&0xff) + (data[i+1]&0xff)),2);

        }

        String onesComplementSum = binary[0];

        for (int j=0; j<binary.length;j++){
            onesComplementSum = onesCompSum(onesComplementSum,binary[j]);

        }

        if(onesComplementSum.length() < 16){
            int length = onesComplementSum.length();
            for (int i=0; i<16-length;i++){
                onesComplementSum = "0" + onesComplementSum;
            }
        }

        return  onesComp(onesComplementSum);

    }

    public byte[] PacketToHash(){
        byte[] seqno = ByteBuffer.allocate(4).putInt(this.seqNum).array();
        byte last = (byte) (this.last ? 1:0);

        byte[] packetToHash = new byte[1+seqno.length+this.data.length];
        packetToHash[0] = last;
        System.arraycopy(seqno,0,packetToHash,1,seqno.length);
        System.arraycopy(this.data,0,packetToHash,seqno.length+1,this.data.length);

        return packetToHash;
    }

    public byte[] generatePacket(){

        byte[] packetToHash = PacketToHash();

        checksum = genCheckSum(packetToHash);
        // Induce checksum error to the packet
        if (Math.random() <= checksum_error) {
            addErrorToChecksum();
        }

        byte[] checksumBytes = checksum.getBytes();

        byte[] packet = new byte[16 + packetToHash.length];

        System.arraycopy(checksumBytes, 0, packet, 0, checksumBytes.length);
        System.arraycopy(packetToHash, 0, packet, checksumBytes.length, packetToHash.length);

        return packet;
    }

    // Add checksum error by inverting the first bit
    public void addErrorToChecksum(){
        if (this.checksum.charAt(0) == '0') {
            this.checksum = "1" + this.checksum.substring(1);
        } else{
            this.checksum = "0" + this.checksum.substring(1);
        }
    }

    // check if the packet is valid by comparing the checksum
    public boolean isValidPacket(){
        byte[] packetToHash = PacketToHash();

        String calculatedChecksum = genCheckSum(packetToHash);

        return this.checksum.equals(calculatedChecksum);
    }

    @Override
    public String toString() {
        return "Packet [seq=" + seqNum + ", data=" + Arrays.toString(data)
                + ", last=" + last + "]";
    }

}
