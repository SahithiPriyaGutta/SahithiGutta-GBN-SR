/* CCN Programming Project 1 - Implementation of GBN and SR Protocols
 ** Project Members - Ravi Teja Kolla and Sahithi Priya Gutta
*/

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Queue;

public class Reciever {

    public static double LOST_ACK = 0.05;
    public static int last_ack_lost = 0;

    public static void main(String args[]) throws Exception{

        if (args.length != 2){
            System.out.println("Not enough arguments expected 2 but got " + args.length);
            return;
        }
        String parameters  = args[0];
        int recieverport;
        List<String> lines = new ArrayList<>();
        try {
            BufferedReader br = new BufferedReader(new FileReader(parameters));
            recieverport = Integer.parseInt(args[1]);

            String line;
            while ((line = br.readLine()) != null) {
                lines.add(line.trim());
            }
            br.close();
        }catch (Exception e){
            System.out.println("Invalid File");
        }
        try{
            recieverport = Integer.parseInt(args[1]);
            DatagramSocket serverSocket = new DatagramSocket(recieverport);
            System.out.println("Server Started: Waiting for packets!!");
            
            String protocol = lines.get(0);

            int m = Integer.parseInt(lines.get(1).split(" ")[0].trim());
            int N = Integer.parseInt(lines.get(1).split(" ")[1].trim());
            int size = Integer.parseInt(lines.get(3));

            // Total Sequence No's allowed
            int x = (int) (Math.pow(2.0, (double) m));

            System.out.println("***********************************");
            System.out.println("Receiving Protocol - " + protocol);
            System.out.println("***********************************");

            if (protocol.equals("GBN")){
                byte[] recievedPacket = new byte[16+1+4+size];
                BufferedWriter bw = new BufferedWriter(new FileWriter("output.txt"));
                boolean end = false;
                int waitingPacket = 0;
                while (!end){
                    DatagramPacket recievePacket = new DatagramPacket(recievedPacket,recievedPacket.length);
                    serverSocket.receive(recievePacket);
                    byte[] recieveData = recievePacket.getData();
                    Packet packet = new Packet(recieveData,recievePacket.getLength());
                    if(packet.isValidPacket()){
                        if(waitingPacket % x == packet.getSeqNum()){

                            System.out.println("recieved segment" + packet.getSeqNum()+ ";");
                            end = packet.getLast();
                            String text = new String(packet.getData());
                            bw.write(text);
                            waitingPacket++;
                        }
                        else {

                            System.out.println("Discarded out of order segment recieved " + packet.getSeqNum());
                        }
                    }
                    else {
                        System.out.println("Discarded " + packet.getSeqNum() + " checksum error");
                    }
                    Ack ackPacket = new Ack((waitingPacket -1)%x);
                    byte[] ackData = ackPacket.generatePacket();
                    Thread.sleep(100);

                    DatagramPacket sendAck = new DatagramPacket(ackData,ackData.length,recievePacket.getAddress(),recievePacket.getPort());
                    if(Math.random() > LOST_ACK){
                        serverSocket.send(sendAck);
                    }
                    else {

                        System.out.println("Lost Ack");
                    }
                    System.out.println("ACK Sent: " + ackPacket.getSeqNum());
                    System.out.println("");
                }

                bw.flush();
                bw.close();

                serverSocket.close();

            }
            else if (protocol.equals("SR")) {

                HashMap<Integer,Packet> recievedPackets = new HashMap<>();
                byte[] recievedPacket = new byte[16+1+4+size];
                BufferedWriter bw = new BufferedWriter(new FileWriter("output.txt"));
                boolean end = false;
                int waiting = 0;
                Queue<Integer> unAckedPackets = new ArrayDeque<>();
                for (int i=0;i<N;i++){
                    unAckedPackets.add(i);
                }
                while (!end){
                    DatagramPacket recievepacket = new DatagramPacket(recievedPacket,recievedPacket.length);
                    serverSocket.receive(recievepacket);
                    byte[] recieveData = recievepacket.getData();
                    Packet packet = new Packet(recieveData,recievepacket.getLength());
                    if(packet.isValidPacket()){
                        System.out.println("Recieved Segment " + packet.getSeqNum());
                        ArrayList<Integer> unAckPackets_list = new ArrayList<Integer>(unAckedPackets);
                        int actualSeqNum = waiting + unAckPackets_list.indexOf(packet.getSeqNum());
                        if(!recievedPackets.containsKey(actualSeqNum)){
                            recievedPackets.put(actualSeqNum,packet);
                            if(waiting != actualSeqNum){
                                System.out.println("out of order recieved; Stored to Buffer; Expecting "+ waiting%x);
                            }

                        }
                        else {
                            System.out.println("Discarded packet" + packet.getSeqNum() + ": Duplicated Packet");
                        }
                        while (recievedPackets.containsKey(waiting)){
                            Packet buffered = recievedPackets.get(waiting);
                            end = buffered.getLast();
                            String text = new String(buffered.getData());
                            bw.write(text);
                            System.out.println("Delievered Packet: "+ waiting%x);
                            unAckedPackets.add((waiting+N)%x);
                            waiting++;
                            unAckedPackets.remove();
                        }
                        Ack ackPacket = new Ack(packet.getSeqNum());
                        byte[] ackData = ackPacket.generatePacket();
                        Thread.sleep(100);

                        DatagramPacket sendAck = new DatagramPacket(ackData,ackData.length,recievepacket.getAddress(),recievepacket.getPort());

                        if(Math.random() > LOST_ACK) {
                            serverSocket.send(sendAck);
                        }
                        else {
                            System.out.println("Lost Ack");
                        }

                        System.out.println("Ack Sent:"  + ackPacket.getSeqNum());
                        System.out.println("");

                    }
                    else {
                        System.out.println("Discarded " + packet.getSeqNum() + "; Checksum Error;");
                    }

                }
                bw.flush();
                bw.close();
                serverSocket.close();

            }
            else {
                serverSocket.close();
            }

        }
        catch (Exception e){
            System.out.println("Invalid Port number");
        }

       
    }
}

